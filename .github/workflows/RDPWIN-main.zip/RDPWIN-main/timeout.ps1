$i = 7200
do {
    Write-Host $i
    Sleep 200
    $i--
} while ($i -gt 0)
